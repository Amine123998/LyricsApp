package app.lyricsapp;

import app.lyricsapp.model.Favorites;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
public class LyricsAPPGUI extends Application {

        private ObservableList<String> songs = FXCollections.observableArrayList();

        // Create an observable list to store the favorite songs
        private ObservableList<String> favorites = FXCollections.observableArrayList();
        private ListView<String> songsListView = new ListView<>(songs);
        private ListView<String> favoritesListView = new ListView<>(favorites);

    @Override
        public void start(Stage stage) {

            // Set the title of the app
            stage.setTitle("Lyrics App");

            // Create the layout for the app
            BorderPane layout = new BorderPane();

            // Create a ListView to display the songs
            //ListView<String> songsListView = new ListView<>(songs);
            songsListView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

            // Create a ListView to display the favorite songs
            //ListView<String> favoritesListView = new ListView<>(favorites);
            favoritesListView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

            // Create buttons to add and remove songs
            Button addSongButton = new Button("Add Song");
            addSongButton.setOnAction(e -> addSong());

            Button removeSongButton = new Button("Remove Song");
            removeSongButton.setOnAction(e -> removeSong());

            // Create a button to add a song to favorites
            Button addToFavoritesButton = new Button("Add to Favorites");
            addToFavoritesButton.setOnAction(e -> addToFavorites());

            // Create a button to remove a song from favorites
            Button removeFromFavoritesButton = new Button("Remove from Favorites");
            removeFromFavoritesButton.setOnAction(e -> removeFromFavorites());

            // Create the layout for the buttons
            HBox buttonLayout = new HBox(10);
            buttonLayout.setPadding(new Insets(10, 10, 10, 10));
            buttonLayout.getChildren().addAll(addSongButton, removeSongButton, addToFavoritesButton, removeFromFavoritesButton);

            // Create the layout for the list views
            VBox listLayout = new VBox(10);
            listLayout.setPadding(new Insets(10, 10, 10, 10));
            listLayout.getChildren().addAll(new Label("Songs"), songsListView, new Label("Favorites"), favoritesListView);

            // Set the layout of the app
            layout.setCenter(listLayout);
            layout.setBottom(buttonLayout);

            // Create the scene
            Scene scene = new Scene(layout, 400, 400);

            // Set the scene and show the stage
            stage.setScene(scene);
            stage.show();
        }

        // Method to add a song to the songs list
        private void addSong() {
            TextInputDialog dialog = new TextInputDialog("");
            dialog.setTitle("Add Song");
            dialog.setHeaderText(null);
            dialog.setContentText("Enter the name of the song:");

            dialog.showAndWait().ifPresent(song -> {
                if (!song.trim().isEmpty()) {
                    songs.add(song);
                }
            });
        }

        // Method to remove a song from the songs list
        private void removeSong() {
            int selectedIndex = songs.indexOf(songsListView.getSelectionModel().getSelectedItem());
            if (selectedIndex >= 0) {
                songs.remove(selectedIndex);
            }
        }

        // Method to add a song to the favorites list
        private void addToFavorites() {
            String song = songsListView.getSelectionModel().getSelectedItem();
            if (song != null && !favorites.contains(song)) {
                favorites.add(song);
            }
        }

        // Method to remove a song from the favorites list
        private void removeFromFavorites() {
            int selectedIndex
                    = favorites.indexOf(favoritesListView.getSelectionModel().getSelectedItem());
            if (selectedIndex >= 0) {
                favorites.remove(selectedIndex);
            }
        }

        public static void main(String[] args) {
            launch(args);
        }

        }

