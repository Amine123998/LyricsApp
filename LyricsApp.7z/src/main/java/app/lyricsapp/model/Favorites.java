package app.lyricsapp.model;

import java.nio.file.Paths;
import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import org.w3c.dom.*;

public class Favorites {
    public static final String xmlFilePath = "Favorites.xml";

    public static void addSong(Song song){
       if (!Files.exists(Paths.get(xmlFilePath))) {

           createXmlFile(song);
       }
       else{

        addXMLTag(song);
       }

    }

    public static void removeSong(String artist, String title) {
        try {
            try {
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();
                Document doc = builder.parse(xmlFilePath);

                NodeList nList = doc.getElementsByTagName("song");
                for (int temp = 0; temp < nList.getLength(); temp++) {
                    Node nNode = nList.item(temp);
                    if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                        Element eElement = (Element) nNode;
                        if (eElement.getElementsByTagName("Title").item(0) != null) {
                            boolean test1 = eElement.getElementsByTagName("Title").item(0).getTextContent().equalsIgnoreCase(title);
                            boolean test2 = eElement.getElementsByTagName("Artist").item(0).getTextContent().equalsIgnoreCase(artist);
                            if (test1 && test2) {
                                if (nList.getLength() == 1){
                                    File myObj = new File(xmlFilePath);
                                    myObj.delete();
                                    System.out.println("Removed successfully");
                                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                    alert.setHeaderText(null);
                                    alert.setContentText("Song removed from favorites successfully.");
                                    alert.showAndWait();
                                }
                                else {
                                    eElement.getParentNode().removeChild(eElement);
                                    TransformerFactory transformerFactory = TransformerFactory.newInstance();
                                    Transformer transformer = transformerFactory.newTransformer();
                                    DOMSource source = new DOMSource(doc);
                                    StreamResult result = new StreamResult(xmlFilePath);
                                    transformer.transform(source, result);
                                    System.out.println("Removed successfully");
                                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                    alert.setHeaderText(null);
                                    alert.setContentText("Song removed from favorites successfully.");
                                    alert.showAndWait();
                                    break;
                                }
                            } else if ((!test1 || !test2) && temp == nList.getLength() - 1) {
                                System.out.println("You don't have this song in your favorites");
                                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                alert.setHeaderText(null);
                                alert.setContentText("You don't have this song in your favorites");
                                alert.showAndWait();
                            }
                        }
                    }
                }
            } catch(Exception e){
                    e.printStackTrace();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

     public static ArrayList<Song> showAll() {
         if (!Files.exists(Paths.get(xmlFilePath))) {
            System.out.println("You don't have favorites yet");
         }
         else {

             try {
                 File fXmlFile = new File(xmlFilePath);
                 DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                 DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                 Document doc = dBuilder.parse(fXmlFile);
                 doc.getDocumentElement().normalize();
                 System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
                 NodeList nList = doc.getElementsByTagName("song");
                 System.out.println("----------------------------");
                 ArrayList<Song> songs = new ArrayList<>();
                 for (int temp = 0; temp < nList.getLength(); temp++) {
                     Node nNode = nList.item(temp);
                     System.out.println("\nCurrent Element :" + nNode.getNodeName());
                     if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                         Element eElement = (Element) nNode;
                         songs.add(new Song(eElement.getElementsByTagName("Title").item(0).getTextContent(),eElement.getElementsByTagName("Artist").item(0).getTextContent(),eElement.getElementsByTagName("Lyric").item(0).getTextContent()));
                         System.out.println("Title : " + eElement.getElementsByTagName("Title").item(0).getTextContent());
                         System.out.println("Artist : " + eElement.getElementsByTagName("Artist").item(0).getTextContent());
                         System.out.println("Lyric : " + eElement.getElementsByTagName("Lyric").item(0).getTextContent());
                     }

                 }
                 return songs;
             } catch (Exception e) {
                 e.printStackTrace();
             }
         }
         return null;
     }

 public static void addXMLTag(Song song){
     try {
         // Create a new instance of DocumentBuilderFactory
         DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
         // Use the factory to create a new document builder
         DocumentBuilder builder = factory.newDocumentBuilder();
         // Parse the XML file to create a Document object
         Document doc = builder.parse(xmlFilePath);
         NodeList nList = doc.getElementsByTagName("song");
         for (int temp = 0; temp < nList.getLength(); temp++) {
             Node nNode = nList.item(temp);
             if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                 Element eElement = (Element) nNode;
                 if (eElement.getElementsByTagName("Title").item(0) != null) {
                     boolean test1 = eElement.getElementsByTagName("Title").item(0).getTextContent().equals(song.getTitle());
                     boolean test2= eElement.getElementsByTagName("Artist").item(0).getTextContent().equals(song.getArtist());
                     if (test1 && test2) {
                        System.out.println(("Already exists"));
                         Alert alert = new Alert(Alert.AlertType.INFORMATION);
                         alert.setHeaderText(null);
                         alert.setContentText("Already exists");
                         alert.showAndWait();
                        break;
                     }
                     else if ((!test1 || !test2) && temp==nList.getLength()-1){
                         // Create a new element
                         Element favoriteSong = doc.createElement("song");

                         doc.getDocumentElement().appendChild(favoriteSong);

                         // Title element
                         Element title = doc.createElement("Title");
                         title.appendChild(doc.createTextNode(song.getTitle()));
                         favoriteSong.appendChild(title);

                         // Artist element
                         Element artist = doc.createElement("Artist");
                         artist.appendChild(doc.createTextNode(song.getArtist()));
                         favoriteSong.appendChild(artist);

                         // Lyrics element
                         Element lyrics = doc.createElement("Lyric");
                         lyrics.appendChild(doc.createTextNode(song.getLyrics()));
                         favoriteSong.appendChild(lyrics);

                         TransformerFactory transformerFactory = TransformerFactory.newInstance();
                         Transformer transformer = transformerFactory.newTransformer();
                         DOMSource source = new DOMSource(doc);
                         StreamResult result = new StreamResult(xmlFilePath);
                         transformer.transform(source, result);
                         System.out.println("Added!");
                         Alert alert = new Alert(Alert.AlertType.INFORMATION);
                         alert.setHeaderText(null);
                         alert.setContentText("Added!");
                         alert.showAndWait();
                         break;
                     }
                 } else {


                 }
             }
         }

     } catch (Exception e) {
         e.printStackTrace();
     }
 }
    public static void createXmlFile(Song song){

        try {

            DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();

            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();

            Document document = documentBuilder.newDocument();

            // root element
            Element root = document.createElement("favorites");
            document.appendChild(root);

            // employee element
            Element favoriteSong = document.createElement("song");

            root.appendChild(favoriteSong);

            // firstname element
            Element title = document.createElement("Title");
            title.appendChild(document.createTextNode(song.getTitle()));
            favoriteSong.appendChild(title);

            // lastname element
            Element artist = document.createElement("Artist");
            artist.appendChild(document.createTextNode(song.getArtist()));
            favoriteSong.appendChild(artist);

            // email element
            Element lyrics = document.createElement("Lyric");
            lyrics.appendChild(document.createTextNode(song.getLyrics()));
            favoriteSong.appendChild(lyrics);


            // create the xml file
            //transform the DOM Object to an XML File
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource domSource = new DOMSource(document);
            StreamResult streamResult = new StreamResult(new File(xmlFilePath));

            // If you use
            // StreamResult result = new StreamResult(System.out);
            // the output will be pushed to the standard output ...
            // You can use that for debugging

            transformer.transform(domSource, streamResult);

            System.out.println("Done creating XML File");
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText("Added!");
            alert.showAndWait();

        } catch (ParserConfigurationException pce) {
            pce.printStackTrace();
        } catch (TransformerException tfe) {
            tfe.printStackTrace();
        }
    }
    public static int lastId() {
        String id = null;
        try {
            File inputFile = new File("Favorites.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("song");
            Node nNode = nList.item(nList.getLength() - 1);
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                id = eElement.getAttribute("id");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Integer.valueOf(id);

    }
}


