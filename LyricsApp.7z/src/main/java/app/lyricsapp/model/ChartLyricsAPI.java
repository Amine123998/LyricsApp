package app.lyricsapp.model;

import app.lyricsapp.model.Song;
import javafx.scene.control.Alert;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;

import static java.lang.Integer.parseInt;

public class ChartLyricsAPI {
    public static void searchByLyric(String lyrics) {
        try {
            List<Song> artistAndSongs = getSongByLyric(lyrics);
            for (Song song : artistAndSongs) {
                System.out.println(song.getArtist() + " - " + song.getTitle()+"\n");
            }
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
    public static void searchByArtistAndName(String artist,String title) {
        try {
            Song song = getSongByArtistAndName(artist,title);
            System.out.println(song.getArtist() + " - " + song.getTitle()+"\n"+song.getLyrics());

        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
    public static String getLyricAPI(String lyricId,String lyricChecksum)throws Exception{
        lyricId = URLEncoder.encode(lyricId, "UTF-8");
        lyricChecksum = URLEncoder.encode(lyricChecksum, "UTF-8");
        String urlStr = "http://api.chartlyrics.com/apiv1.asmx/GetLyric?lyricId="+lyricId+"&lyricCheckSum="+lyricChecksum;
        URL url = new URL(urlStr);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        String xmlStr = response.toString();
        Pattern p = Pattern.compile("<Lyric>(.*?)</Lyric>", Pattern.DOTALL | Pattern.MULTILINE);
        Matcher m = p.matcher(xmlStr);
        if (m.find()) {
            return m.group(1);
        }
        return "No match";
    }
    public static List<Song> getSongByLyric(String lyrics) throws Exception {
        lyrics = URLEncoder.encode(lyrics, "UTF-8");
        String urlStr = "http://api.chartlyrics.com/apiv1.asmx/SearchLyricText?lyricText=" + lyrics;
        URL url = new URL(urlStr);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        String xmlStr = response.toString();
        Pattern p = Pattern.compile("<LyricChecksum>(.*?)</LyricChecksum>.*?<LyricId>(.*?)</LyricId>.*?<Artist>(.*?)</Artist>.*?<Song>(.*?)</Song>", Pattern.DOTALL | Pattern.MULTILINE);
        Matcher m = p.matcher(xmlStr);

        List<Song> artistAndSongsList = new ArrayList<>();
        while (m.find()) {
            Song song = new Song(m.group(4),m.group(3),getLyricAPI(m.group(2),m.group(1)),parseInt(m.group(2)),m.group(1));
            artistAndSongsList.add(song);
        }
        if (artistAndSongsList.isEmpty()){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText("No song with such lyrics!");
            alert.showAndWait();
        }
        return artistAndSongsList;
    }
    public static Song getSongByArtistAndName(String artist,String title) throws Exception {
        artist = URLEncoder.encode(artist, "UTF-8");
        title = URLEncoder.encode(title, "UTF-8");
        String urlStr = "http://api.chartlyrics.com/apiv1.asmx/SearchLyricDirect?artist="+artist+"&song="+title;
        URL url = new URL(urlStr);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        String xmlStr = response.toString();
        Pattern p = Pattern.compile("<LyricChecksum>(.*?)</LyricChecksum>.*?<LyricId>(.*?)</LyricId>.*?<LyricSong>(.*?)</LyricSong>.*?<LyricArtist>(.*?)</LyricArtist>.*?<Lyric>(.*?)</Lyric>", Pattern.DOTALL | Pattern.MULTILINE);
        Matcher m = p.matcher(xmlStr);
        if (m.find()) {
            return new Song(m.group(3),m.group(4),m.group(5),parseInt(m.group(2)),m.group(1));
        }
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText("This Song doesn't exist");
        alert.showAndWait();
        return null;
    }
}
