package app.lyricsapp.model;

import app.lyricsapp.model.Favorites;
import app.lyricsapp.model.Song;

public class Main {
    public static void main(String[] args) {

        Song song = new Song("Hello", "Zaid", "Hello bikom", 15, "Hello");

        Favorites.addSong(song);

        Song song2 = new Song("Hi", "ELg", "Hello ", 20, "NO");
        Favorites.addSong(song2);

  

    }
}