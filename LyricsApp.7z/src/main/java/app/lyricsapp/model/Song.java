package app.lyricsapp.model;

public class Song {
    private String title;
    private String artist;
    private String lyrics;
    private int lyricId;
    private String lyricCheckSum;
    public Song(String title, String artist, String lyrics, int lyricId, String lyricCheckSum){
        this.title=title;
        this.artist=artist;
        this.lyrics=lyrics;
        this.lyricId=lyricId;
        this.lyricCheckSum=lyricCheckSum;
    }
    public Song(String title, String artist, String lyrics){
        this.title=title;
        this.artist=artist;
        this.lyrics=lyrics;
    }

    public String getTitle(){
        return this.title;
    }

    public String getArtist(){
        return this.artist;
    }

    public String getLyrics(){
        return this.lyrics;
    }

    protected int getLyricsId(){
        return this.lyricId;
    }

    protected String getLyricCheckSum(){
        return this.lyricCheckSum;
    }
    @Override
    public String toString(){
        return getTitle()+" by "+getArtist();
    }
}
