package app.lyricsapp;

import app.lyricsapp.model.ChartLyricsAPI;
import app.lyricsapp.model.Favorites;

import java.util.Scanner;

public class LyricsAppCLI {
    public static void main(String[] args) throws Exception {
        System.out.println("Welcome to the lyrics app");

        System.out.println("1-Find a song.\n2-My favorites. \nPlease select a number");
        Scanner scanner = new Scanner(System.in);

        int choice_menu = scanner.nextInt();
        while (choice_menu != 1 && choice_menu !=2 ){
            System.out.println("Please enter a valid choice");
            choice_menu=scanner.nextInt();
        }
        if (choice_menu==1){
            System.out.println("Search by: \n 1-Artist && Title \n 2-Lyrics");
            int song_search  = scanner.nextInt();
            Scanner scn = new Scanner(System.in);
            while (song_search != 1 && song_search !=2 ){
                System.out.println("Please enter a valid choice");
                song_search=scanner.nextInt();
            }
            if(  song_search == 1) {
                System.out.println("Enter artist name:");
                String artist= scn.nextLine();
                System.out.println("Enter song name:");
                String title= scn.nextLine();
                ChartLyricsAPI.searchByArtistAndName(artist,title);
            } else if ( song_search  == 2) {
                System.out.println("Enter a text in lyrics:");
                String text= scn.nextLine();
                ChartLyricsAPI.searchByLyric(text);
            }

        }
        else if (choice_menu==2){
            System.out.println("\n 1-Show all favorites \n 2-Add a song\n 3-Remove a song");
            int favorites_choice  = scanner.nextInt();
            while (favorites_choice != 1 && favorites_choice !=2 && favorites_choice !=3 ){
                System.out.println("Please enter a valid choice");
                favorites_choice=scanner.nextInt();
            }
            Scanner scn = new Scanner(System.in);
            if (favorites_choice==1){
                System.out.println("your favorites: ");
                Favorites.showAll();
            }
            else if(favorites_choice==2){
                System.out.println("Enter artist name:");
                String artist= scn.nextLine();
                System.out.println("Enter song name:");
                String title= scn.nextLine();
                Favorites.addSong(ChartLyricsAPI.getSongByArtistAndName(artist,title));
            }
            else if(favorites_choice==3){
                System.out.println("Enter artist name:");
                String artist= scn.nextLine();
                System.out.println("Enter song name:");
                String title= scn.nextLine();
                Favorites.removeSong(artist,title);
            }
        }else {
            System.out.println("Sorry, I can't do anything yet ! (Read: " + scanner.nextLine() +")");
            scanner.close();
        }



    }
}
