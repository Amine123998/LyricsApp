package app.lyricsapp.controller;

import app.lyricsapp.model.Favorites;
import app.lyricsapp.model.Song;
import app.lyricsapp.model.ChartLyricsAPI;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.net.URL;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class LyricsAppController implements Initializable {
    public Button removeFromFavoritesButton;
    public Button addToFavoritesButton;
    public TextField LyricsField;
    @FXML
    private TextArea favoritesList;
    @FXML
    private TextField songField;

    @FXML
    private TextField artistField;

    @FXML
    private TextArea lyricsLabel;

    @FXML
    private TextField lyricsField;
    private Scene scene;
    @FXML
    private Button searchLyricsButton;
    private Stage stage;
    @FXML
    private TextArea searchResultTextArea;
    @FXML
    private TextField songToAdd;
    @FXML
    private TextField artistToAdd;
    @FXML
    private TextField songToRemove;
    @FXML
    private TextField artistToRemove;

    public void setStage(Stage stage) {
        this.showAll();
        this.stage = stage;
    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println(("Raeched Successfully"));
        showAll();
    }
    public  void showAll() {
        List<Song> songs = Favorites.showAll();
        StringBuilder result = new StringBuilder();
        try {
            favoritesList.clear(); // clear the TextArea
            if (songs == null){
                favoritesList.setText("You don't have any favorite songs yet");
            }
            else {
                for (Song song : songs) {
                    result.append(song.getArtist()).append(" - ").append(song.getTitle()).append("\n");

                }
                favoritesList.setText(result.toString());
            }
        } catch (Exception e) {
            favoritesList.setText("Error: " + e.getMessage());
        }
    }





    @FXML
    public void searchLyricsByLyrics() {
        String lyrics = LyricsField.getText();
        if (lyrics.isEmpty()) {
            searchResultTextArea.setText("Please enter a lyrics to look for");
            return;
        }
        if (lyrics.length()==1) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText("Please give a lyrics longer than one character!");
            alert.showAndWait();
            return;
        }
        try {
            List<Song> songs = ChartLyricsAPI.getSongByLyric(lyrics);
            StringBuilder result = new StringBuilder();
            for (Song song : songs) {
                result.append(song.getArtist()).append(" - ").append(song.getTitle()).append("\n");
            }
            searchResultTextArea.setText(result.toString());
        } catch (Exception e) {
            searchResultTextArea.setText("An error occurred: " + e.getMessage());
        }

    }
    @FXML
    public void searchLyrics() {
        String songName = songField.getText().trim();
        String artistName = artistField.getText().trim();

        if (songName.isEmpty() || artistName.isEmpty()) {
            lyricsLabel.setText("Please enter a song name and artist name");
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText("Please enter a song name and artist name");
            alert.showAndWait();
            return;
        }

        try {
            String lyrics = ChartLyricsAPI.getSongByArtistAndName(artistName, songName).getLyrics();
            lyricsLabel.clear(); // clear the TextArea
            lyricsLabel.appendText(lyrics);
        } catch (Exception e) {
        }
    }
    @FXML
    public void addToFavorites() {
        String songTitle = songToAdd.getText().trim();
        String artistName = artistToAdd.getText().trim();

        if (songTitle.isEmpty() || artistName.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText("Please enter all song details!");
            alert.showAndWait();
            return;
        }

        try {
            Favorites.addSong(ChartLyricsAPI.getSongByArtistAndName(artistName,songTitle));

            showAll();
        } catch (Exception e) {
            lyricsLabel.setText("Error adding song: " + e.getMessage());
        }
    }
    public void removeFromFavorites() {
        String songTitle = songToRemove.getText().trim();
        String artistName = artistToRemove.getText().trim();

        if (songTitle.isEmpty() || artistName.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText("Please enter all song details!");
            alert.showAndWait();
            return;
        }

        try {
            Favorites.removeSong(artistName,songTitle);

            showAll();
        } catch (Exception e) {
            lyricsLabel.setText("Error removing song: " + e.getMessage());
        }
    }



}
