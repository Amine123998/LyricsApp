package app.lyricsapp.controller;

import app.lyricsapp.model.Song;
import app.lyricsapp.model.Favorites;

import java.nio.file.Files;
import java.nio.file.Paths;

public class FavoritesController {
    private static final String XML_FILE_PATH = "Favorites.xml";

    public static void addSong(Song song) {
        if (!Files.exists(Paths.get(XML_FILE_PATH))) {
            Favorites.createXmlFile(song);
        } else {
            Favorites.addXMLTag(song);
        }
    }

    public static void removeSong(String artist, String title) {
        Favorites.removeSong(artist, title);
    }

    public static void showAll() {
        Favorites.showAll();
    }
}
