package app.lyricsapp;

import app.lyricsapp.model.ChartLyricsAPI;
import app.lyricsapp.model.Song;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LyricsAppFX extends Application {

    private TextField artistField, titleField, lyricsField;
    private TextArea lyricsArea;
    private Button searchButton, clearButton;

    @Override
    public void start(Stage primaryStage) throws Exception {
        BorderPane root = new BorderPane();

        // top section
        VBox topBox = new VBox(10);
        topBox.setPadding(new Insets(10));
        topBox.setAlignment(Pos.CENTER);
        Label titleLabel = new Label("Lyrics App");
        titleLabel.setStyle("-fx-font-size: 24px;");
        HBox artistBox = new HBox(10);
        artistBox.setAlignment(Pos.CENTER);
        Label artistLabel = new Label("Artist: ");
        artistField = new TextField();
        artistBox.getChildren().addAll(artistLabel, artistField);
        HBox titleBox = new HBox(10);
        titleBox.setAlignment(Pos.CENTER);
        Label titleLabel2 = new Label("Title: ");
        titleField = new TextField();
        titleBox.getChildren().addAll(titleLabel2, titleField);
        topBox.getChildren().addAll(titleLabel, artistBox, titleBox);

        // center section
        VBox centerBox = new VBox(10);
        centerBox.setPadding(new Insets(10));
        centerBox.setAlignment(Pos.CENTER);
        lyricsField = new TextField();
        lyricsField.setEditable(false);
        lyricsField.setStyle("-fx-font-weight: bold;");
        lyricsField.setPrefWidth(500);
        lyricsArea = new TextArea();
        lyricsArea.setEditable(false);
        centerBox.getChildren().addAll(lyricsField, lyricsArea);

        // bottom section
        HBox bottomBox = new HBox(10);
        bottomBox.setPadding(new Insets(10));
        bottomBox.setAlignment(Pos.CENTER);
        searchButton = new Button("Search");
        clearButton = new Button("Clear");
        bottomBox.getChildren().addAll(searchButton, clearButton);

        root.setTop(topBox);
        root.setCenter(centerBox);
        root.setBottom(bottomBox);

        // event handlers
        searchButton.setOnAction(e -> {
            String artist = artistField.getText();
            String title = titleField.getText();
            try {
                Song song = ChartLyricsAPI.getSongByArtistAndName(artist, title);
                if (song != null) {
                    lyricsField.setText(song.getArtist() + " - " + song.getTitle());
                    lyricsArea.setText(song.getLyrics());
                } else {
                    lyricsField.setText("Couldn't find song");
                    lyricsArea.clear();
                }
            } catch (Exception ex) {
                lyricsField.setText("An error occurred: " + ex.getMessage());
                lyricsArea.clear();
            }
        });

        clearButton.setOnAction(e -> {
            artistField.clear();
            titleField.clear();
            lyricsField.clear();
            lyricsArea.clear();
        });

        // create scene and show stage
        Scene scene = new Scene(root);
        primaryStage.setTitle("Lyrics App");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
