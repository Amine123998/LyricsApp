package app.lyricsapp;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;

public class XMLReader {
    private static int numberOfSongsFound;
    public static void main(String[] args) {
        try {
            File fXmlFile = new File("src/main/resources/app/lyricsapp/view/XMLFile.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);
            doc.getDocumentElement().normalize();
            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
            NodeList nList = doc.getElementsByTagName("SearchLyricResult");
            System.out.println("----------------------------");
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                System.out.println("\nCurrent Element :" + nNode.getNodeName());
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    System.out.println("TrackId : " );
                    System.out.println((eElement.getElementsByTagName("TrackId").item(0).getTextContent()));
                    System.out.println("LyricChecksum : ");
                    System.out.println((eElement.getElementsByTagName("LyricChecksum").item(0).getTextContent()));
                    System.out.println("LyricId : ");
                    System.out.println((eElement.getElementsByTagName("LyricId").item(0).getTextContent()));
                    System.out.println("SongUrl : ");
                    System.out.println((eElement.getElementsByTagName("SongUrl").item(0).getTextContent()));
                    System.out.println("ArtistUrl : ");
                    System.out.println((eElement.getElementsByTagName("ArtistUrl").item(0).getTextContent()));
                    System.out.println("Artist : ");
                    System.out.println((eElement.getElementsByTagName("Artist").item(0).getTextContent()));
                    System.out.println("Song : ");
                    System.out.println((eElement.getElementsByTagName("Song").item(0).getTextContent()));
                    System.out.println("SongRank : ");
                    System.out.println((eElement.getElementsByTagName("SongRank").item(0).getTextContent()));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void TrackIdTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("TrackId").item(0).getTextContent()));
    }
    public static void LyricChecksumTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("LyricChecksum").item(0).getTextContent()));
    }
    public static void LyricIdTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("LyricId").item(0).getTextContent()));
    }
    public static void SongUrlTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("SongUrl").item(0).getTextContent()));

    }
    public static void ArtistUrlTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("ArtistUrl").item(0).getTextContent()));
    }
    /*public static void ArtistTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("Artist").item(0).getTextContent()));
    }
    public static void SongTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("Song").item(0).getTextContent()));
    }*/
    /*public static void SongRankTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("SongRank").item(0).getTextContent()));
    }*/
    public static void getSong(String artist,String title){
        try {
            File fXmlFile = new File("src/main/resources/app/lyricsapp/view/XMLFile.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("SearchLyricResult");
            System.out.println("----------------------------");
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    if (eElement.getElementsByTagName("Song").item(0) != null) {
                        boolean test1 = eElement.getElementsByTagName("Song").item(0).getTextContent().equals(title);
                        boolean test2= eElement.getElementsByTagName("Artist").item(0).getTextContent().equals(artist);
                        if (test1 && test2) {
                            System.out.print("Artist : ");
                            System.out.println(eElement.getElementsByTagName("Artist").item(0).getTextContent());
                            System.out.print("Song : ");
                            System.out.println((eElement.getElementsByTagName("Song").item(0).getTextContent()));
                            numberOfSongsFound++;
                            /*System.out.println("Lyrics : ");
                            System.out.println((eElement.getElementsByTagName("Lyric").item(0).getTextContent()));*/ ;
                        }
                        else if((!test1 || !test2) && temp == nList.getLength()-2 && (numberOfSongsFound ==0 )){
                            System.out.println("Doesn't exist");
                        }
                        }
                    else {
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*public static void getTitle(String title){
        try {
            File fXmlFile = new File("src/main/resources/app/lyricsapp/view/XMLFile.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("SearchLyricResult");
            System.out.println("----------------------------");
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    if (eElement.getElementsByTagName("Song").item(0) != null) {
                        boolean test = eElement.getElementsByTagName("Song").item(0).getTextContent().equals(title);
                        if (test) {
                            System.out.print("Artist : ");
                            System.out.println(eElement.getElementsByTagName("Artist").item(0).getTextContent());
                            System.out.print("Song : ");
                            System.out.println((eElement.getElementsByTagName("Song").item(0).getTextContent()));
                            /*System.out.println("Lyrics : ");
                            System.out.println((eElement.getElementsByTagName("Lyric").item(0).getTextContent()));

                        }
                    }
                    else {
                        System.out.println("Doesn't exist");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }*/
}
