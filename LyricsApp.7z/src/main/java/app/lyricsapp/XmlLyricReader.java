package app.lyricsapp;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;

public class XmlLyricReader {
    public static void main(String[] args) {
        try {
            File fXmlFile = new File("src/main/resources/app/lyricsapp/view/XMLFile2.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);
            doc.getDocumentElement().normalize();
            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
            NodeList nList = doc.getElementsByTagName("GetLyricResult");
            System.out.println("----------------------------");
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                System.out.println("\nCurrent Element :" + nNode.getNodeName());
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    System.out.println("TrackId : " );
                    TrackIdTag(eElement);
                    System.out.println("LyricChecksum : ");
                    LyricChecksumTag(eElement);
                    System.out.println("LyricId : ");
                    LyricIdTag(eElement);
                    System.out.println("LyricSong : ");
                    LyricSongTag(eElement);
                    System.out.println("LyricArtist : ");
                    LyricArtistTag(eElement);
                    System.out.println("LyricUrl : ");
                    LyricUrlTag(eElement);
                    System.out.println("LyricRank : ");
                    LyricRankTag(eElement);
                    System.out.println("LyricCorrectUrl : ");
                    LyricCorrectUrlTag(eElement);
                    System.out.println("Lyric : ");
                    LyricTag(eElement);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void TrackIdTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("TrackId").item(0).getTextContent()));
    }
    public static void LyricChecksumTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("LyricChecksum").item(0).getTextContent()));
    }
    public static void LyricIdTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("LyricId").item(0).getTextContent()));
    }
    public static void LyricSongTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("LyricSong").item(0).getTextContent()));
    }
    public static void LyricArtistTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("LyricArtist").item(0).getTextContent()));
    }
    public static void LyricUrlTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("LyricUrl").item(0).getTextContent()));
    }
    public static void LyricRankTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("LyricRank").item(0).getTextContent()));
    }
    public static void LyricCorrectUrlTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("LyricCorrectUrl").item(0).getTextContent()));
    }
    public static void LyricTag(Element eElement){
        System.out.println((eElement.getElementsByTagName("Lyric").item(0).getTextContent()));
    }
    public static void getLyric(Element eElement){
        System.out.println((eElement.getElementsByTagName("Lyric").item(0).getTextContent()));
    }
}
